const express = require("express");

const server = express();

const logRequest = (req, res, next) => {
  console.log(req.method);
  console.log(req.path);
  next();
};

server.get("/", logRequest, (req, res) => {
  res.send("Request logged successfully");
});

module.exports = server;
