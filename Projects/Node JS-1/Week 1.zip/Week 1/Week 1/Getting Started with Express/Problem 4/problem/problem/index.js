const express = require("express");
const server = express();

const setCustomHeader = (res, headerName, headerValue) => {
  res.setHeader(headerName, headerValue);

  console.log(
    `${headerName} with value ${headerValue} has been set successfully`
  );
};

server.get("/", (req, res) => {
  setCustomHeader(res, "Content-Type", "application/json");
  res.send(`get method called!`);
});

module.exports = { setCustomHeader, server };
