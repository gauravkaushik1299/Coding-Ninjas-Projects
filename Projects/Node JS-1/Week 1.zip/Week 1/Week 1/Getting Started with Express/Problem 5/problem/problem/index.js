const express = require("express");
const path = require("path");
const server = express();

const renderStatic = () => {
  server.use(express.static(path.join(__dirname, "public")));
};

server.get("/", (req, res) => {
  res.send("get method called!");
});

renderStatic();

module.exports = { renderStatic, server };
