import fs from "fs";

/**
 * Appends the user's blog content to the given file path
 * @param {string} filePath
 * @param {string} blogContent
 */
export const writeBlog = (filePath, blogContent) => {
  fs.appendFileSync(filePath, blogContent);
};

/**
 * Reads and returns the blog content from the given file path
 * @param {string} filePath
 * @returns {string}
 */
export const publishBlog = (filePath) => {
  return fs.readFileSync(filePath, "utf-8");
};
