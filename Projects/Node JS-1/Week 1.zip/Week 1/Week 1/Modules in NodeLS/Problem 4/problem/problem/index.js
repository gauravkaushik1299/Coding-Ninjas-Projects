// Import required module
const readline = require("readline");
const Solution = () => {
  // Write your code here
  const qInterface = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  qInterface.question("Enter the first number: ", (firstInput) => {
    const num1 = Number(firstInput);
    qInterface.question("Enter the second number: ", (secondInput) => {
      const num2 = Number(secondInput);
      const maxValue = Math.max(num1, num2);
      console.log(`The maximum of the two numbers is: ${maxValue}`);
      qInterface.close();
    });
  });
};

Solution();
module.exports = Solution;
