// Please don't change the pre-written code
// Import the necessary modules here
import nodemailer from "nodemailer";
import readline from "readline";

const Solution = () => {
  // Write your code here
  const qInterface = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  qInterface.question("Enter recipient email: ", async (receiverEmail) => {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "your_email@gmail.com",
        pass: "your_app_password",
      },
    });

    const mailOptions = {
      from: "your_email@gmail.com",
      to: receiverEmail,
      subject: "Coding Ninjas",
      text: "The world has enough coders; be a coding ninja!",
    };

    try {
      await transporter.sendMail(mailOptions);
      console.log("Email sent successfully");
    } catch (error) {
      console.error(error.message);
    } finally {
      qInterface.close();
    }
  });
};

export default Solution;
