const http = require("http");
const fs = require("fs");

const server = http.createServer((req, res) => {
  if (req.method === "POST") {
    let body = "";

    req.on("data", (chunk) => {
      body += chunk.toString();
    });

    req.on("end", () => {
      fs.appendFileSync("data.txt", body);

      const fileData = fs.readFileSync("data.txt", "utf-8");

      console.log(fileData);

      res.writeHead(200, { "Content-Type": "text/plain" });
      res.end("Data received and stored successfully");
    });
  } else {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end("Send a POST request to store data");
  }
});

server.listen(3000);

export default server;
