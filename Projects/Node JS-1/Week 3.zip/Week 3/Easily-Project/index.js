import express from "express";
import path from "path";
import JobController from "./src/controller/jobs.controller.js";
import UserController from "./src/controller/user.controller.js";
import ejsLayouts from "express-ejs-layouts";
import session from "express-session";
import cookieParser from "cookie-parser";

import { authGuard } from "./src/middleware/auth.middleware.js";
import applicationValidator from "./src/middleware/jobApply.middleware.js";
import signupValidator from "./src/middleware/Registervalidation.middleware.js";
import { visitLogger } from "./src/middleware/lastVisit.middleware.js";
import { resumeUploader } from "./src/middleware/file.upload.middleware.js";

import ApplicantController from "./src/controller/applicant.controller.js";

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(path.resolve(), "src", "views"));

app.use(cookieParser());
app.use(visitLogger);
app.use(ejsLayouts);
app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: "SecretKey",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false },
  }),
);

const jobcontroller = new JobController();
const usercontroller = new UserController();
const applicantcontroller = new ApplicantController();

app.use(express.static("public"));
app.use(express.static("src/views"));

app.post("/register", signupValidator, (req, res) => {
  if (req.session.user) {
    return res.redirect("/jobs");
  }
  usercontroller.registerUser(req, res);
});

app.get("/login", (req, res) => {
  if (req.session.user) {
    return res.redirect("/jobs");
  }
  usercontroller.showLoginPage(req, res);
});

app.post("/login", usercontroller.authenticateUser);
app.get("/logout", usercontroller.signOut);

app.get("/jobs/filter", jobcontroller.performJobSearch);
app.get("/jobs", jobcontroller.displayAllJobs);
app.get("/", jobcontroller.showLandingPage);

app.get("/jobs/:id", visitLogger, jobcontroller.displayJobDetails);

app.get("/job/update/:id", authGuard, jobcontroller.renderUpdatePage);
app.post("/job/update/:id", authGuard, jobcontroller.modifyJobDetails);
app.post("/job/delete/:id", authGuard, jobcontroller.removeJob);

app.get("/postjob", authGuard, jobcontroller.renderPostJobForm);
app.post("/jobs", authGuard, jobcontroller.createNewJob);

app.get("/job/applicants/:id", applicantcontroller.getApplicantsById);

app.post(
  "/job/applicants/:id",
  resumeUploader.single("resumePath"),
  applicationValidator,
  applicantcontroller.addApplicantById,
);

app.get("/404", jobcontroller.displayErrorPage);

app.listen(3200);
console.log("Easily Job Portal started successfully on port 3200");
