function deleteJob(event, id) {
  event.preventDefault(); // Prevent form submission

  // Confirm user before deleting job.
  const result = confirm("Are you sure you want to delete this job");
  if (result) {
    fetch("/job/delete/" + id, {
      method: "POST",
    }).then((res) => {
      if (res.ok) {
        window.location.href = "/jobs";
      }
    });
  }
}

function updateJob(event, id) {
  event.preventDefault(); // Prevent form submission

  // Confirm user before updating job.  // Fetch job details for update.
  const result = confirm("Are you sure you want to update this job?");
  console.log(result);
  if (result) {
    window.location.href = "/job/update/" + id;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const buttons = document.querySelectorAll(".bookmark-btn");

  buttons.forEach((btn) => {
    const jobId = btn.dataset.id;

    if (isBookmarked(jobId)) {
      btn.textContent = "★ Bookmarked";
    }

    btn.addEventListener("click", () => toggleBookmark(jobId, btn));
  });
});

function toggleBookmark(jobId, button) {
  let savedJobs = JSON.parse(localStorage.getItem("savedJobs")) || [];

  if (savedJobs.includes(jobId)) {
    savedJobs = savedJobs.filter((id) => id !== jobId);
    button.textContent = "☆ Bookmark";
  } else {
    savedJobs.push(jobId);
    button.textContent = "★ Bookmarked";
  }

  localStorage.setItem("savedJobs", JSON.stringify(savedJobs));
}

function isBookmarked(jobId) {
  const savedJobs = JSON.parse(localStorage.getItem("savedJobs")) || [];
  return savedJobs.includes(jobId);
}

/* =========================
   THEME TOGGLE LOGIC
   ========================= */

document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("themeToggleBtn");
  const savedTheme = localStorage.getItem("theme");

  if (savedTheme) {
    document.body.setAttribute("data-theme", savedTheme);
  }

  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      const currentTheme = document.body.getAttribute("data-theme");

      if (currentTheme === "light") {
        document.body.removeAttribute("data-theme");
        localStorage.setItem("theme", "dark");
      } else {
        document.body.setAttribute("data-theme", "light");
        localStorage.setItem("theme", "light");
      }
    });
  }
});
