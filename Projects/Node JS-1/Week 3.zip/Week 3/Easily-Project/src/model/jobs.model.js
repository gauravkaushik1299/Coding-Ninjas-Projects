import { jobs } from "../assets/jobs.js";

/**
 * Model class for managing job-related data and operations.
 * Provides static methods to interact with the jobs array, including fetching, modifying, and searching jobs.
 */
export default class JobsModel {
  /**
   * Retrieves all jobs from the data source.
   * @returns {Array<Object>} An array of all job objects.
   */
  static fetchAllJobs() {
    return jobs;
  }

  static getSortedJobs(sortKey) {
    const jobList = [...jobs];

    if (sortKey === "salary") {
      return jobList.sort((a, b) => {
        const minA = parseInt(a.salary);
        const minB = parseInt(b.salary);
        return minB - minA;
      });
    }

    if (sortKey === "latest") {
      return jobList.sort(
        (a, b) => new Date(b.jobposted) - new Date(a.jobposted),
      );
    }

    return jobList;
  }

  /**
   * Fetches a specific job by its ID.
   * @param {number} jobId - The unique identifier of the job.
   * @returns {Object|null} The job object if found, otherwise null.
   */
  static fetchJobById(jobId) {
    return jobs.find((singleJob) => singleJob.id == jobId);
  }

  /**
   * Adds a new applicant to a specific job.
   * @param {number} id - The ID of the job to add the applicant to.
   * @param {string} name - The name of the applicant.
   * @param {string} email - The email of the applicant.
   * @param {string} contact - The contact number of the applicant.
   * @param {string} resume - The path to the applicant's resume.
   */
  static addApplicantToJob(id, name, email, contact, resume) {
    const jobIndex = jobs.findIndex((record) => record.id == id);

    let newApplicantId = jobs[jobIndex].applicants.length + 1;

    jobs[jobIndex].applicants.push({
      applicantId: newApplicantId,
      name: name,
      email: email,
      contact: contact,
      resumePath: resume,
    });
  }

  /**
   * Modifies an existing job with new data.
   * @param {number} id - The ID of the job to modify.
   * @param {Object} jobData - The new data for the job.
   * @param {string} jobData.jobcategory - The job category.
   * @param {string} jobData.jobdesignation - The job designation.
   * @param {string} jobData.jobLocation - The job location.
   * @param {string} jobData.companyname - The company name.
   * @param {string} jobData.salary - The salary range.
   * @param {string} jobData.applyBy - The application deadline.
   * @param {number} jobData.TotalPositions - The number of openings.
   * @param {Array<string>} jobData.skillsRequired - The required skills.
   */
  static modifyExistingJob(id, jobData) {
    const position = jobs.findIndex((item) => item.id == id);

    if (position != -1) {
      jobs[position].jobcategory = jobData.jobcategory;
      jobs[position].jobdesignation = jobData.jobdesignation;
      jobs[position].joblocation = jobData.jobLocation;
      jobs[position].companyname = jobData.companyname;
      jobs[position].salary = jobData.salary;
      jobs[position].applyby = jobData.applyBy;
      jobs[position].numberofopenings = jobData.TotalPositions;
      jobs[position].skillsRequired = jobData.skillsRequired;
      jobs[position].applicants = [];
    }
  }

  /**
   * Removes a job record from the data source.
   * @param {number} id - The ID of the job to remove.
   */
  static removeJobRecord(id) {
    const position = jobs.findIndex((entry) => entry.id == id);

    if (position != -1) {
      jobs.splice(position, 1);
    }
  }

  /**
   * Fetches the list of applicants for a specific job.
   * @param {number} id - The ID of the job.
   * @returns {Array<Object>} An array of applicant objects for the job.
   */
  static fetchApplicants(id) {
    const jobData = jobs.find((item) => item.id == id);
    return jobData ? jobData.applicants : [];
  }

  /**
   * Inserts a new job into the data source.
   * @param {Object} newJobData - The data for the new job.
   * @param {string} newJobData.jobcategory - The job category.
   * @param {string} newJobData.jobdesignation - The job designation.
   * @param {string} newJobData.joblocation - The job location.
   * @param {string} newJobData.companyname - The company name.
   * @param {string} newJobData.salary - The salary range.
   * @param {string} newJobData.applyby - The application deadline.
   * @param {Array<string>} newJobData.skillsRequired - The required skills.
   * @param {number} newJobData.numberofopenings - The number of openings.
   * @param {number} recruiterId - The ID of the recruiter posting the job.
   */
  static insertNewJob(newJobData, recruiterId) {
    const {
      jobcategory,
      jobdesignation,
      joblocation,
      companyname,
      salary,
      applyby,
      skillsRequired,
      numberofopenings,
    } = newJobData;

    const freshJob = {};

    freshJob.id = jobs.length + 1;
    freshJob.recruiterId = recruiterId;
    freshJob.jobcategory = jobcategory;
    freshJob.jobdesignation = jobdesignation;
    freshJob.joblocation = joblocation;
    freshJob.companyname = companyname;
    freshJob.salary = salary;
    freshJob.applyby = applyby;
    freshJob.skillsRequired = skillsRequired;
    freshJob.numberofopenings = numberofopenings;
    freshJob.applicants = [];
    freshJob.jobposted = new Date().toISOString();

    jobs.push(freshJob);
  }

  /**
   * Searches for jobs based on a query string.
   * Matches against company name, job designation, location, and category.
   * @param {string} queryText - The search query.
   * @returns {Array<Object>} An array of jobs that match the search criteria.
   */
  static searchJobs(queryText) {
    const searchTerm = queryText.trim().toLowerCase();

    return jobs.filter((jobItem) => {
      return (
        jobItem.companyname.toLowerCase().includes(searchTerm) ||
        jobItem.jobdesignation.toLowerCase().includes(searchTerm) ||
        jobItem.joblocation.toLowerCase().includes(searchTerm) ||
        jobItem.jobcategory.toLowerCase().includes(searchTerm)
      );
    });
  }
}
