/**
 * Model class for managing user data and authentication.
 * Provides methods to create users, verify credentials, and store user information.
 */
export default class UserModel {
  /**
   * Creates a new UserModel instance.
   * @param {number} id - The unique identifier for the user.
   * @param {string} name - The name of the user.
   * @param {string} email - The email address of the user.
   * @param {string} password - The password of the user.
   */
  constructor(id, name, email, password) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.password = password;
  }

  /**
   * Inserts a new user into the users array.
   * @param {Object} userDetails - The details of the user to insert.
   * @param {string} userDetails.name - The name of the user.
   * @param {string} userDetails.email - The email of the user.
   * @param {string} userDetails.password - The password of the user.
   */
  static insertUser(userDetails) {
    const newUser = new UserModel(
      users.length + 1,
      userDetails.name,
      userDetails.email,
      userDetails.password,
    );

    users.push(newUser);
  }

  /**
   * Verifies user credentials by checking email and password.
   * @param {string} email - The email of the user.
   * @param {string} password - The password of the user.
   * @returns {Object|null} The user object if credentials match, otherwise null.
   */
  static verifyCredentials(email, password) {
    console.log(users);
    return users.find(
      (singleUser) =>
        singleUser.email === email && singleUser.password === password,
    );
  }
}

/**
 * In-memory array to store user data.
 * This serves as a simple data store for user information.
 * @type {Array<UserModel>}
 */
const users = [];
