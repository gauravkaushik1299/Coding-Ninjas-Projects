/**
 * Array of job postings data.
 * This module exports a static array of job objects, each representing a job listing
 * with details such as category, designation, location, company, salary, application deadline,
 * required skills, number of openings, posting date, recruiter ID, and a list of applicants.
 *
 * @type {Array<Object>} jobs - The array of job objects.
 * @property {number} id - Unique identifier for the job.
 * @property {string} jobcategory - Category of the job (e.g., "Tech").
 * @property {string} jobdesignation - Designation or title of the job (e.g., "SDE").
 * @property {string} joblocation - Location of the job (e.g., "Gurgaon HR IND Remote").
 * @property {string} companyname - Name of the company offering the job.
 * @property {string} salary - Salary range for the job (e.g., "14-20lpa").
 * @property {string} applyby - Application deadline date.
 * @property {Array<string>} skillsRequired - List of required skills for the job.
 * @property {number} numberofopenings - Number of available positions.
 * @property {string} jobposted - Date and time when the job was posted.
 * @property {number} recruiterId - ID of the recruiter who posted the job.
 * @property {Array<Object>} applicants - Array of applicant objects who have applied for the job.
 * @property {number} applicants[].applicantId - Unique ID of the applicant.
 * @property {string} applicants[].name - Name of the applicant.
 * @property {string} applicants[].email - Email address of the applicant.
 * @property {string} applicants[].contact - Contact number of the applicant.
 * @property {string} applicants[].resumePath - Path to the applicant's resume file.
 */
export const jobs = [
  {
    id: 1,
    jobcategory: "Tech",
    jobdesignation: "Frontend Developer",
    joblocation: "Hyderabad IND Remote",
    companyname: "TechNova Solutions",
    salary: "10-15 LPA",
    applyby: "15 Oct 2025",
    skillsRequired: ["HTML", "CSS", "JavaScript", "React", "Git"],
    numberofopenings: 4,
    jobposted: "3/10/2025, 10:20:00 AM",
    recruiterId: 1,
    applicants: [],
  },
  {
    id: 2,
    jobcategory: "Tech",
    jobdesignation: "Backend Engineer",
    companyname: "BlueWave Systems",
    joblocation: "Chennai IND On-site",
    salary: "12-18 LPA",
    applyby: "25 Nov 2025",
    skillsRequired: ["NodeJS", "Express", "MongoDB", "REST API"],
    numberofopenings: 6,
    jobposted: "5/10/2025, 02:15:30 PM",
    recruiterId: 2,
    applicants: [],
  },
  {
    id: 3,
    jobcategory: "Non-tech",
    jobdesignation: "Digital Marketing Executive",
    companyname: "NextGen Media",
    joblocation: "Delhi IND Hybrid",
    salary: "5-8 LPA",
    applyby: "30 Dec 2025",
    skillsRequired: ["SEO", "Content Writing", "Social Media"],
    numberofopenings: 3,
    jobposted: "7/10/2025, 09:40:12 AM",
    recruiterId: 3,
    applicants: [],
  },
];
