export const visitLogger = (req, res, next) => {
  if (req.cookies && req.cookies.lastVisit) {
    res.locals.lastVisit = new Date(req.cookies.lastVisit).toLocaleString();
  }

  res.cookie("lastVisit", new Date().toISOString(), {
    maxAge: 48 * 60 * 60 * 1000,
  });

  next();
};
