import { validationResult, body } from "express-validator";
import JobsModel from "../model/jobs.model.js";

const applicationValidator = async (req, res, next) => {
  const checks = [
    body("name").notEmpty().withMessage("Please provide your full name"),
    body("email").isEmail().withMessage("A valid email address is required"),
    body("contact")
      .isMobilePhone()
      .withMessage("Enter a correct mobile number"),
    body("resumepath").custom((value, { req }) => {
      if (!req.file) {
        throw new Error("Resume file must be uploaded");
      }
      return true;
    }),
  ];

  await Promise.all(checks.map((check) => check.run(req)));

  const result = validationResult(req);

  if (!result.isEmpty()) {
    const jobId = req.params.id;
    const job = JobsModel.getJobById(jobId);

    return res.render("job_details", {
      job,
      user: null,
      errorMessage: result.array()[0].msg,
    });
  }

  next();
};

export default applicationValidator;
