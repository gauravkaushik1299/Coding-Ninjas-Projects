import multer from "multer";

const uploadConfig = multer.diskStorage({
  destination: (req, file, callback) => {
    callback(null, "public/resumes/");
  },

  filename: (req, file, callback) => {
    const uniqueName = `${Date.now()}_${file.originalname}`;
    callback(null, uniqueName);
  },
});

export const resumeUploader = multer({ storage: uploadConfig });
