import nodemailer from "nodemailer";
import fs from "fs";
import path from "path";

const templatePath = path.resolve("public", "html", "mail.html");
const emailTemplate = fs.readFileSync(templatePath);

async function sendConfirmationEmail(receiver) {
  const mailer = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "qwerty123@gmail.com",
      pass: "asdfghjkl@123",
    },
  });

  const message = {
    from: "qwerty123@gmail.com",
    to: receiver,
    subject: "Job Application Submitted Successfully",
    html: emailTemplate,
  };

  try {
    await mailer.sendMail(message);
    console.log("Confirmation mail delivered");
  } catch (err) {
    console.log("Mail sending failed", err);
  }
}

export default sendConfirmationEmail;
