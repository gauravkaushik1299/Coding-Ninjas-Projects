import { validationResult, body } from "express-validator";

const signupValidator = async (req, res, next) => {
  const rules = [
    body("name").notEmpty().withMessage("Name field cannot be empty"),
    body("email").isEmail().withMessage("Enter a proper email address"),
    body("password")
      .isLength({ min: 8 })
      .withMessage("Password must contain at least 8 characters")
      .matches(/[A-Z]/)
      .withMessage("Password should include an uppercase letter")
      .matches(/[a-z]/)
      .withMessage("Password should include a lowercase letter")
      .matches(/\d/)
      .withMessage("Password should contain at least one number")
      .matches(/[!@#$%&*(),.{}|<>]/)
      .withMessage("Password should contain one special symbol"),
  ];

  await Promise.all(rules.map((rule) => rule.run(req)));

  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.render("index", {
      errorMessage: errors.array(),
      user: null,
    });
  }

  next();
};

export default signupValidator;
