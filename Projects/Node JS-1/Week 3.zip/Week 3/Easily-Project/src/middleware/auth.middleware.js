/**
 * Middleware function to authenticate users.
 * Checks if the user has a session email; if not, redirects to login page.
 * @param {Object} req - The HTTP request object.
 * @param {Object} res - The HTTP response object.
 * @param {Function} next - The next middleware function in the stack.
 */
export const authGuard = (req, res, next) => {
  if (req.session && req.session.email) {
    return next();
  }
  return res.redirect("/login");
};
