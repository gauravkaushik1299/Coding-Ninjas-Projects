import JobsModel from "../model/jobs.model.js";
import SendMail from "../middleware/confirmationMail.middleware.js";

/**
 * Controller class for handling applicant-related operations.
 * Manages retrieving applicants for a job and adding new applicants.
 */
export default class ApplicantController {
  /**
   * Retrieves and displays applicants for a specific job.
   * Checks if the user is logged in as a recruiter before allowing access.
   * @param {Object} req - The request object containing parameters and session data.
   * @param {Object} res - The response object for rendering views or redirecting.
   */
  getApplicantsById(req, res) {
    const jobId = req.params.id;

    const applicantRecords = JobsModel.getApplicants(jobId);
    const selectedJob = JobsModel.getJobById(jobId);

    if (req.session.user) {
      res.render("applicants", {
        job: selectedJob,
        applicants: applicantRecords,
        user: req.session.user,
      });
    } else {
      res.redirect(
        `/404?errorMessage=only recruiter is allowed to access this page, login as recruiter to continue`,
      );
    }
  }

  /**
   * Adds a new applicant to a specific job.
   * Handles file upload for resume and sends a confirmation email.
   * @param {Object} req - The request object containing body data and uploaded file.
   * @param {Object} res - The response object for rendering views.
   * @param {Function} next - The next middleware function in the chain.
   */
  async addApplicantById(req, res, next) {
    const jobId = req.params.id;

    const { name, email, contact } = req.body;
    const uploadedResume = req.file.filename;

    console.log(req.body);

    JobsModel.addApplicant(jobId, name, email, contact, uploadedResume);

    const allJobs = JobsModel.getJobs();

    if (!allJobs) {
      res.redirect(`/404?errorMessage=Page not found.`);
    } else {
      await SendMail(email);

      res.render("joblistings", {
        jobs: allJobs,
        user: req.session.user,
      });
    }
  }
}
