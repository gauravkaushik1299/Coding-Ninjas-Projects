import JobsModel from "../model/jobs.model.js";

/**
 * Controller class for handling job-related operations.
 * Manages displaying jobs, job details, creating, updating, deleting jobs, and searching.
 */
export default class JobController {
  /**
   * Displays the landing page of the application.
   * @param {Object} req - The request object.
   * @param {Object} res - The response object for rendering the index view.
   */
  showLandingPage(req, res) {
    res.render("index", { user: req.session.user, errorMessage: null });
  }

  /**
   * Displays all available jobs.
   * @param {Object} req - The request object.
   * @param {Object} res - The response object for rendering the job listings view.
   */
  displayAllJobs(req, res) {
    const sortType = req.query.sort;
    const jobRecords = sortType
      ? JobsModel.getSortedJobs(sortType)
      : JobsModel.fetchAllJobs();

    res.render("joblistings", {
      jobs: jobRecords,
      user: req.session.user,
    });
  }

  /**
   * Displays details of a specific job.
   * @param {Object} req - The request object containing the job ID.
   * @param {Object} res - The response object for rendering the job details view.
   */
  displayJobDetails(req, res) {
    const jobId = req.params.id;
    const selectedJob = JobsModel.fetchJobById(jobId);

    if (!selectedJob) {
      res.redirect(`/404?errorMessage=Page not found.`);
    } else {
      res.render("job_details", {
        job: selectedJob,
        user: req.session.user,
        errorMessage: null,
      });
    }
  }

  /**
   * Renders the update job page for authorized recruiters.
   * @param {Object} req - The request object containing the job ID.
   * @param {Object} res - The response object for rendering the update view.
   */
  renderUpdatePage(req, res) {
    const jobId = req.params.id;
    const jobData = JobsModel.fetchJobById(jobId);

    console.log(jobData);

    if (!jobData.recruiterId || jobData.recruiterId === req.session.user.id) {
      res.render("update_job", { job: jobData });
    } else {
      res.redirect(
        `/404?errorMessage=only posted recruiter is allowed to access this page.`,
      );
    }
  }

  /**
   * Modifies the details of an existing job.
   * @param {Object} req - The request object containing updated job data.
   * @param {Object} res - The response object for redirecting after update.
   */
  modifyJobDetails(req, res) {
    const jobId = req.params.id;
    console.log(req.body.skillsRequired);

    JobsModel.modifyExistingJob(jobId, req.body);
    res.redirect(`/jobs/${jobId}`);
  }

  /**
   * Removes a job posting for authorized recruiters.
   * @param {Object} req - The request object containing the job ID.
   * @param {Object} res - The response object for sending status or rendering error.
   */
  removeJob(req, res) {
    const jobId = req.params.id;
    const jobInfo = JobsModel.fetchJobById(jobId);

    if (!jobInfo.recruiterId || jobInfo.recruiterId === req.session.user.id) {
      JobsModel.removeJobRecord(jobId);
      return res.status(200).send("Job deleted successfully");
    } else {
      res.render("error", {
        errorMessage: "only posted recruiter is allowed to delete this Job",
      });
    }
  }

  /**
   * Renders the form for posting a new job.
   * @param {Object} req - The request object.
   * @param {Object} res - The response object for rendering the new job form.
   */
  renderPostJobForm(req, res) {
    res.render("new-job", { user: req.session.user });
  }

  /**
   * Creates a new job posting.
   * @param {Object} req - The request object containing job data.
   * @param {Object} res - The response object for redirecting after creation.
   */
  createNewJob(req, res) {
    const recruiterIdentifier = req.session.user.id;
    JobsModel.insertNewJob(req.body, recruiterIdentifier);
    res.redirect("/jobs");
  }

  /**
   * Displays an error page with a custom message.
   * @param {Object} req - The request object containing query parameters.
   * @param {Object} res - The response object for rendering the error view.
   */
  displayErrorPage(req, res) {
    console.log("req query", req.query);
    const errorMessage = req.query.errorMessage || "page not found";

    res.render("error", { errorMessage });
  }

  /**
   * Performs a search for jobs based on a query string.
   * @param {Object} req - The request object containing the search query.
   * @param {Object} res - The response object for sending JSON results or redirecting.
   */
  performJobSearch(req, res) {
    if (!req.query.query) {
      return res.redirect("/error?errorMessage=Invalid search query");
    }

    const searchText = req.query.query.toLowerCase();
    console.log("Search Query:", searchText);

    const matchedJobs = JobsModel.searchJobs(searchText);

    if (!matchedJobs.length) {
      return res.json({ jobs: [] });
    }

    res.json({ jobs: matchedJobs });
  }
}
