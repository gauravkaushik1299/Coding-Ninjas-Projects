import JobsModel from "../model/jobs.model.js";
import UserModel from "../model/user.model.js";

/**
 * Controller class for handling user-related operations.
 * Manages user registration, login, authentication, and logout.
 */
export default class UserController {
  /**
   * Registers a new user and redirects to the login page.
   * @param {Object} req - The request object containing user data.
   * @param {Object} res - The response object for redirecting.
   */
  registerUser(req, res) {
    console.log(req.body);
    UserModel.insertUser(req.body);
    res.redirect("/login");
  }

  /**
   * Displays the login page.
   * @param {Object} req - The request object.
   * @param {Object} res - The response object for rendering the login view.
   */
  showLoginPage(req, res) {
    res.render("login");
  }

  /**
   * Authenticates a user based on email and password.
   * Sets session data and redirects to job listings on success.
   * @param {Object} req - The request object containing login credentials.
   * @param {Object} res - The response object for rendering views or redirecting.
   */
  authenticateUser(req, res) {
    const { email, password } = req.body;

    const validUser = UserModel.verifyCredentials(email, password);
    const jobRecords = JobsModel.fetchAllJobs();

    if (!validUser) {
      res.redirect(`/404?errorMessage=User not found.Please Register`);
    } else {
      req.session.user = validUser;
      req.session.email = email;

      res.render("joblistings", {
        jobs: jobRecords,
        user: req.session.user,
      });
    }
  }

  /**
   * Logs out the user by destroying the session.
   * @param {Object} req - The request object.
   * @param {Object} res - The response object for redirecting to login.
   */
  signOut(req, res) {
    req.session.destroy(() => {
      res.redirect("/login");
    });
  }
}
