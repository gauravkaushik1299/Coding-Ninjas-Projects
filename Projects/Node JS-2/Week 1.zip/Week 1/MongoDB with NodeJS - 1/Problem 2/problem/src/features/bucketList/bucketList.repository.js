// Please don't change the pre-written code
// Import the necessary modules here
import { getDB } from "../../config/mongodb.js";

class BucketListRepository {
  constructor() {
    this.collection = "bucketListItems";
  }

  async addBucketListItem(bucketListItem) {
    const db = getDB();
    const collection = db.collection(this.collection);

    const result = await collection.insertOne(bucketListItem);

    return {
      ...bucketListItem,
      _id: result.insertedId,
    };
  }

  async findOneBucketListItem(title) {
    const db = getDB();
    const collection = db.collection(this.collection);

    return await collection.findOne({ title });
  }
}

export default BucketListRepository;
