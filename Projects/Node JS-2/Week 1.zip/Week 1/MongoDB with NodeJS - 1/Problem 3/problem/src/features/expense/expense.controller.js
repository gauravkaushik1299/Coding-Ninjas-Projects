import ExpenseRepository from "./expense.repository.js";

export default class ExpenseController {
  constructor() {
    this.expenseRepository = new ExpenseRepository();
  }

  add = async (req, res) => {
    try {
      const expense = await this.expenseRepository.addExpense(req.body);
      res.status(201).json(expense);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  };

  getOne = async (req, res) => {
    try {
      const expense = await this.expenseRepository.getOne(req.params.id);

      if (!expense) {
        return res.status(404).json({ message: "Expense not found" });
      }

      res.json(expense);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  };

  getAll = async (req, res) => {
    try {
      const expenses = await this.expenseRepository.getAllExpenses();
      res.json(expenses);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  };

  addTag = async (req, res) => {
    try {
      const updatedExpense = await this.expenseRepository.addTagToExpense(
        req.params.id,
        req.body.tag,
      );

      res.json(updatedExpense);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  };

  filter = async (req, res) => {
    try {
      const expenses = await this.expenseRepository.filterExpenses(req.query);

      res.json(expenses);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  };
}
