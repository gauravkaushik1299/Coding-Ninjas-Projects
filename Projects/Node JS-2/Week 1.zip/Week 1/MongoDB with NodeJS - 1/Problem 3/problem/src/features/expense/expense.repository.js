import { getDB } from "../../config/mongodb.js";
import { ObjectId } from "mongodb";

class ExpenseRepository {
  constructor() {
    this.collectionName = "expenses";
  }

  async addExpense(expense) {
    const db = getDB();
    const collection = db.collection(this.collectionName);

    const result = await collection.insertOne(expense);
    return { ...expense, _id: result.insertedId };
  }

  async getOne(id) {
    const db = getDB();
    const collection = db.collection(this.collectionName);

    return await collection.findOne({ _id: new ObjectId(id) });
  }

  async getAllExpenses() {
    const db = getDB();
    const collection = db.collection(this.collectionName);

    return await collection.find().toArray();
  }

  async addTagToExpense(id, tag) {
    const db = getDB();
    const collection = db.collection(this.collectionName);

    await collection.updateOne(
      { _id: new ObjectId(id) },
      { $push: { tags: tag } },
    );

    return this.getOne(id);
  }

  async filterExpenses(criteria) {
    const db = getDB();
    const collection = db.collection(this.collectionName);

    const { minAmount, maxAmount, isRecurring } = criteria;
    const filter = {};

    if (minAmount) {
      filter.amount = { ...filter.amount, $gte: Number(minAmount) };
    }

    if (maxAmount) {
      filter.amount = { ...filter.amount, $lte: Number(maxAmount) };
    }

    if (isRecurring !== undefined) {
      filter.isRecurring = isRecurring === "true";
    }

    return await collection.find(filter).toArray();
  }
}

export default ExpenseRepository;
