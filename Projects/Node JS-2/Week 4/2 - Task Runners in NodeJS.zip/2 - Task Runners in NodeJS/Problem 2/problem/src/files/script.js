console.log("Hello JS");
