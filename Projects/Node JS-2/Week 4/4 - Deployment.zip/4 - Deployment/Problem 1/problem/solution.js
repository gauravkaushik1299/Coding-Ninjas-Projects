export const AWS_LINK = "http://54.252.237.174:5000/";
export const PORT = 3000;
