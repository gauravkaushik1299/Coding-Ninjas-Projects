import server from "./app.js";

const port = 5000;

server.listen(port, "0.0.0.0", () => {
  console.log(`Server running on port ${port}`);
});
