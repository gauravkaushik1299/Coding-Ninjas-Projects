// Please don't change the pre-written code
// Import the necessary modules here

import { ObjectId } from "mongodb";
import { getClient, getDB } from "../../config/mongodb.js";

const collectionName = "students";

class studentRepository {
  async addStudent(studentData) {
    const db = getDB();
    await db.collection(collectionName).insertOne(studentData);
  }

  async getAllStudents() {
    const db = getDB();
    const students = await db.collection(collectionName).find({}).toArray();
    return students;
  }

  async createIndexes() {
    const db = getDB();
    const collection = db.collection(collectionName);

    await collection.createIndex({ name: 1 });
    await collection.createIndex({ age: 1, grade: -1 });

    return true;
  }

  async getStudentsWithAverageScore() {
    const db = getDB();

    return await db
      .collection(collectionName)
      .aggregate([
        { $unwind: "$assignments" },
        {
          $group: {
            _id: "$name",
            averageScore: { $avg: "$assignments.score" },
          },
        },
        {
          $project: {
            _id: 0,
            name: "$_id",
            averageScore: 1,
          },
        },
      ])
      .toArray();
  }

  async getQualifiedStudentsCount() {
    const db = getDB();

    const result = await db
      .collection(collectionName)
      .aggregate([
        { $match: { age: { $gt: 9 }, grade: { $lte: "B" } } },
        { $unwind: "$assignments" },
        {
          $match: {
            "assignments.title": "math",
            "assignments.score": { $gte: 60 },
          },
        },
        { $group: { _id: "$_id" } },
        { $count: "qualifiedCount" },
      ])
      .toArray();

    return result.length > 0 ? result[0].qualifiedCount : 0;
  }

  async updateStudentGrade(studentId, assignmentTitle, extraCredit) {
    const client = getClient();
    const db = getDB();
    const collection = db.collection(this.collectionName);

    const session = client.startSession();

    try {
      let updatedStudent;

      await session.withTransaction(async () => {
        await collection.updateOne(
          {
            _id: new ObjectId(studentId),
            "assignments.title": assignmentTitle,
          },
          {
            $inc: { "assignments.$.score": extraCredit },
          },
          { session },
        );

        // Fetch updated assignments
        const student = await collection.findOne(
          { _id: new ObjectId(studentId) },
          { session },
        );

        const scores = student.assignments.map((a) => a.score);
        const avg = scores.reduce((sum, val) => sum + val, 0) / scores.length;

        // Determine grade
        let grade;
        if (avg >= 90) grade = "A";
        else if (avg >= 80) grade = "B";
        else if (avg >= 70) grade = "C";
        else if (avg >= 60) grade = "D";
        else grade = "F";

        await collection.updateOne(
          { _id: new ObjectId(studentId) },
          { $set: { grade } },
          { session },
        );

        updatedStudent = await collection.findOne(
          { _id: new ObjectId(studentId) },
          { session },
        );
      });

      return updatedStudent;
    } finally {
      await session.endSession();
    }
  }
}

export default studentRepository;
