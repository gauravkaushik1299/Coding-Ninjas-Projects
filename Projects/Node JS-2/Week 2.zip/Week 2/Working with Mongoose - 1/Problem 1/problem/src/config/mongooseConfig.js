import mongoose from "mongoose";

export const connectUsingMongoose = async () => {
  try {
    await mongoose.connect("mongodb://localhost:27017");

    console.log("MongoDB connected using mongoose");
  } catch (error) {
    console.error("MongoDB connection failed", error);
    process.exit(1);
  }
};
