import BookRepository from "./book.repository.js";

export default class BookController {
  constructor() {
    this.bookRepository = new BookRepository();
  }

  // creation of book
  createBook = async (req, res) => {
    try {
      const book = await this.bookRepository.createBook(req.body);
      res.status(201).json(book);
    } catch (error) {
      res.status(500).json({ message: "Error creating book" });
    }
  };

  // filtering of book by id
  getOne = async (req, res) => {
    try {
      const { bookId } = req.params;

      const book = await this.bookRepository.getOne(bookId);

      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }

      res.status(200).json(book);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving book" });
    }
  };
}
