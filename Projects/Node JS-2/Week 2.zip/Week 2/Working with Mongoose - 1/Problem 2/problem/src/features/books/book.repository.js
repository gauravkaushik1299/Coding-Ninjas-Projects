import mongoose from "mongoose";
import { bookSchema } from "./book.schema.js";

const Book = mongoose.models.Book || mongoose.model("Book", bookSchema);

export default class BookRepository {
  // book creation
  async createBook(bookData) {
    const book = new Book(bookData);
    return await book.save();
  }

  // filtering the book by id
  async getOne(id) {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return null;
    }

    return await Book.findById(id);
  }
}
