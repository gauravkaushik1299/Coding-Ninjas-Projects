//-----------pre-written code starts----------
import BookRepository from "./book.repository.js";

export default class BookController {
  constructor() {
    this.bookRepository = new BookRepository();
  }

  //book creation
  createBook = async (req, res) => {
    const { title, author, genre, copies, availableCopies } = req.body;
    try {
      const bookData = {
        title,
        author,
        genre,
        copies,
        availableCopies,
      };
      await this.bookRepository.createBook(bookData);
      res.status(201).json(bookData);
    } catch (err) {
      console.log(err);
      res.status(500).json({ error: "Failed to create a new book" });
    }
  };

  //filtering the book by id
  getOne = async (req, res) => {
    const { bookId } = req.params;
    console.log(bookId);

    try {
      const book = await this.bookRepository.getOne(bookId);
      if (!book) {
        res.status(404).send("book  not found.");
      } else {
        res.status(200).send(book);
      }
    } catch (err) {
      console.log(err);
      res.status(500).json({ error: "Failed to find book" });
    }
  };

  //---------------pre-written code ends-----------------

  // Complete the functions below:

  // list books by genre
  listBooksByGenre = async (req, res) => {
    try {
      const { genre } = req.params;

      const books = await this.bookRepository.listBooksByGenre(genre);

      res.status(200).json(books);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving books by genre" });
    }
  };

  // update available copies
  updateBookAvailability = async (req, res) => {
    try {
      const { bookId } = req.params;
      const { incrementBy } = req.body;

      const updatedBook = await this.bookRepository.updateBookAvailability(
        bookId,
        incrementBy,
      );

      if (!updatedBook) {
        return res.status(404).json({ message: "Book not found" });
      }

      res.status(200).json(updatedBook);
    } catch (error) {
      res.status(500).json({ message: "Error updating book availability" });
    }
  };

  // delete a book
  deleteBook = async (req, res) => {
    try {
      const { bookId } = req.params;

      const deletedBook = await this.bookRepository.deleteBook(bookId);

      if (!deletedBook) {
        return res.status(404).json({ message: "Book not found" });
      }

      res.status(200).json({ message: "Book deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting book" });
    }
  };
}
