import mongoose from "mongoose";
import { jobSchema } from "./schema/job.schema.js";
import { applyJobSchema } from "./schema/application.schema.js";
import { userSchema } from "../user/user.schema.js";

const JobModel = mongoose.model("Job", jobSchema);
const ApplicationModel = mongoose.model("Application", applyJobSchema);
const UserModel = mongoose.model("User", userSchema);
export const findUserById = async (id) => {
  return await UserModel.findById(id);
};
export const createNewJob = async (job) => {
  const newJob = new JobModel({
    title: job.title,
    description: job.description,
    company: job.company,
    salary: job.salary,
    applicants: [],
  });

  return await newJob.save();
};

export const findJobRepo = async (_id) => {
  return await JobModel.findById(_id);
};

export const applyJobRepo = async (jobId, userId) => {
  const job = await JobModel.findById(jobId);
  if (!job) return null;

  const existingApplication = await ApplicationModel.findOne({
    jobId,
    userId,
  });

  if (existingApplication) {
    return null;
  }

  const newApplication = new ApplicationModel({
    jobId,
    userId,
  });

  await newApplication.save();

  // ensure applicants array exists
  if (!job.applicants) {
    job.applicants = [];
  }

  job.applicants.push(userId);
  await job.save();

  return job; // RETURN UPDATED JOB (important)
};
