import mongoose from "mongoose";

export const likeSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    likeable: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      refPath: "on_model",
    },
    on_model: {
      type: String,
      required: true,
      enum: ["User", "Job"],
    },
  },
  { timestamps: true },
);
