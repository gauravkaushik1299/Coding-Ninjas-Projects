import mongoose from "mongoose";
import { likeSchema } from "./like.schema.js";

const LikeModel = mongoose.model("Like", likeSchema);

export const likeRepo = async (user_id, job_id, model) => {
  if (model !== "Job" && model !== "User") {
    throw new Error("Invalid model type");
  }

  // Prevent duplicate likes
  const existingLike = await LikeModel.findOne({
    user: user_id,
    likeable: job_id,
    on_model: model,
  });

  if (existingLike) {
    return null;
  }

  const like = new LikeModel({
    user: user_id,
    likeable: job_id,
    on_model: model,
  });

  return await like.save();
};

export const getLikesRepo = async (id, on_model) => {
  if (on_model !== "Job" && on_model !== "User") {
    throw new Error("Invalid model type");
  }

  return await LikeModel.find({
    likeable: id,
    on_model,
  }).populate("user");
};
