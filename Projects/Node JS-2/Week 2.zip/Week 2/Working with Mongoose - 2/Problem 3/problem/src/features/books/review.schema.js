import mongoose from "mongoose";

export const reviewSchema = new mongoose.Schema({
  text: {
    type: String,
    required: [true, "Review text is required"],
    trim: true,
  },

  rating: {
    type: Number,
    required: [true, "Rating is required"],
    min: [1, "Rating must be at least 1"],
    max: [5, "Rating must be at most 5"],
  },

  target: {
    type: String,
    enum: ["Author", "Book"],
    required: true,
  },

  targetId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    refPath: "target",
  },
});
