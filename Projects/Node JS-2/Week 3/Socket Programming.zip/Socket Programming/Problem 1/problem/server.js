import express from "express";
import http from "http";
import { Server } from "socket.io";

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("./"));

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  // Join Room
  socket.on("joinRoom", ({ username, room }) => {
    socket.join(room);
    console.log(`${username} joined room ${room}`);
  });

  // Send Message
  socket.on("sendMessage", ({ username, room, message }) => {
    io.to(room).emit("receiveMessage", {
      username,
      message,
    });
  });

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

server.listen(3000, () => {
  console.log("Server running on port 3000");
});
