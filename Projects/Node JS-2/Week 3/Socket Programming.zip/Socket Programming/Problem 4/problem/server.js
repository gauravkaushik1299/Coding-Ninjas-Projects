import express from "express";
import http from "http";
import { Server } from "socket.io";
import mongoose from "mongoose";
import Task from "./task.schema.js";

const app = express();
const server = http.createServer(app);
const io = new Server(server);

mongoose
  .connect("mongodb://127.0.0.1:27017/taskApp")
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log(err));

app.use(express.static("./"));

io.on("connection", async (socket) => {
  console.log("User connected");

  // Send existing tasks
  const tasks = await Task.find().sort({ createdAt: 1 });
  socket.emit("loadTasks", tasks);

  // Add Task
  socket.on("addTask", async (text) => {
    const newTask = await Task.create({ text });
    io.emit("addTask", newTask);
  });

  // Delete Task
  socket.on("deleteTask", async (taskId) => {
    await Task.findByIdAndDelete(taskId);
    io.emit("deleteTask", taskId);
  });

  // Update Task
  socket.on("updateTask", async ({ taskId, newText }) => {
    const updatedTask = await Task.findByIdAndUpdate(
      taskId,
      { text: newText },
      { new: true },
    );
    io.emit("updateTask", updatedTask);
  });

  socket.on("disconnect", () => {
    console.log("User disconnected");
  });
});

server.listen(3000, () => {
  console.log("Server running on port 3000");
});
